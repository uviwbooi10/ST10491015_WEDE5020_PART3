/* Ou, de Marni — app.js
   Part 3 additions:
   - Cart & wishlist (localStorage) (existing)
   - Tabs (existing)
   - Scent Finder Quiz (existing)
   - Checkout rendering (existing)
   - Lightbox gallery
   - Product search/filter
   - Form validation helpers for enquiry/contact pages
   - events for cart updates
*/

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

/* Storage helper */
const store = {
  get(k, d){ try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v){ localStorage.setItem(k, JSON.stringify(v)); }
};

const CART_KEY = 'odm_cart';
const WISHLIST_KEY = 'odm_wishlist';

/* ---------- Cart & Wishlist ---------- */

function emitCartUpdated(){ window.dispatchEvent(new CustomEvent('cart:updated')); }

function addToCart(item){
  const cart = store.get(CART_KEY, []);
  const existing = cart.find(p => p.id === item.id);
  if(existing) existing.qty = (existing.qty||1) + (item.qty||1);
  else cart.push({...item, qty: item.qty || 1});
  store.set(CART_KEY, cart);
  updateCartBadge();
  emitCartUpdated();
  // subtle visual feedback
  const badgeEls = $$('.cart-count');
  badgeEls.forEach(b => {
    b.classList.add('pulse');
    setTimeout(()=>b.classList.remove('pulse'), 600);
  });
}

function addToWishlist(item){
  const wish = store.get(WISHLIST_KEY, []);
  if(!wish.find(p => p.id === item.id)) wish.push(item);
  store.set(WISHLIST_KEY, wish);
  alert('Saved to wishlist ♥');
}

function changeQty(id, delta){
  const cart = store.get(CART_KEY, []);
  const p = cart.find(x => x.id === id); if(!p) return;
  p.qty = (p.qty||1) + delta;
  if(p.qty <= 0){ const i = cart.findIndex(x => x.id === id); cart.splice(i,1); }
  store.set(CART_KEY, cart);
  updateCartBadge();
  emitCartUpdated();
}

function removeFromCart(id){
  const cart = store.get(CART_KEY, []).filter(i => i.id !== id);
  store.set(CART_KEY, cart);
  updateCartBadge();
  emitCartUpdated();
}

function updateCartBadge(){
  const cart = store.get(CART_KEY, []);
  const count = cart.reduce((s,i)=>s+(i.qty||1),0);
  $$('.cart-count').forEach(el => el.textContent = count);
}

/* Button delegation for add to cart / wishlist */
document.addEventListener('click', e => {
  const btn = e.target.closest('[data-add]');
  if(!btn) return;
  const card = btn.closest('[data-product]');
  if(!card) return;
  const item = {
    id: card.dataset.id,
    name: card.dataset.name,
    price: Number(card.dataset.price),
    img: $('img', card)?.getAttribute('src')
  };
  if(btn.dataset.add === 'cart') addToCart(item);
  if(btn.dataset.add === 'wishlist') addToWishlist(item);
});

/* ---------- Tabs ---------- */
function initTabs(){
  $$('.tabs').forEach(tabs => {
    tabs.addEventListener('click', e => {
      const tab = e.target.closest('.tab'); if(!tab) return;
      const id = tab.dataset.target;
      $$('.tab', tabs).forEach(t=>t.classList.toggle('active', t===tab));
      const panes = tabs.nextElementSibling;
      if(!panes) return;
      $$(':scope > section', panes).forEach(p=>p.classList.toggle('active', p.id === id));
    });
    const first = $('.tab', tabs); if(first) first.click();
  });
}

/* ---------- Scent Finder Quiz ---------- */
function initQuiz(){
  const form = $('#quiz-form'); if(!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const mood = form.mood.value;
    const strength = form.strength.value;
    const season = form.season.value;
    const picks = [];

    if(mood==='calm' && season==='summer') picks.push('Salt Air');
    if(mood==='bold') picks.push('Night EDT');
    if(mood==='romantic' || season==='spring') picks.push('The Scent for HER');
    if(!picks.length) picks.push('Discovery Set');

    $('#quiz-result').innerHTML = `
      <div class="card">
        <div class="card-body">
          <h3>Your picks</h3>
          <p class="lead">We recommend: <strong>${picks.join(', ')}</strong></p>
          <a class="button" href="shop.html#all">Shop recommendations</a>
        </div>
      </div>`;
  });
}

/* ---------- Checkout rendering & controls ---------- */
function initCheckout(){
  const form = $('#checkout-form'); if(!form) return;
  const list = $('#checkout-items');
  const totalEl = $('#checkout-total');

  function render(){
    const cart = store.get(CART_KEY, []);
    if(list){
      list.innerHTML = cart.map(i => `
        <li data-id="${i.id}">
          ${i.name} × ${i.qty} <span>R ${(i.price * i.qty).toFixed(2)}</span>
          <button class="icon-btn" data-cart="minus" title="Decrease">−</button>
          <button class="icon-btn" data-cart="plus" title="Increase">+</button>
          <button class="icon-btn" data-cart="remove" title="Remove">✕</button>
        </li>
      `).join('');
    }
    const total = cart.reduce((s,i)=> s + i.price * (i.qty||1), 0);
    if(totalEl) totalEl.textContent = `R ${total.toFixed(2)}`;
  }

  render();
  window.addEventListener('cart:updated', render);

  list?.addEventListener('click', (e) => {
    const li = e.target.closest('li[data-id]'); if(!li) return;
    const id = li.getAttribute('data-id');
    if(e.target.matches('[data-cart="minus"]')) changeQty(id, -1);
    if(e.target.matches('[data-cart="plus"]')) changeQty(id, +1);
    if(e.target.matches('[data-cart="remove"]')) removeFromCart(id);
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    alert('Order placed! (Demo) — Integrate PayPal/PayFlex/Credit Card in production.');
    localStorage.removeItem(CART_KEY);
    updateCartBadge();
    emitCartUpdated();
  });
}

/* ---------- Product search/filter ---------- */
function initSearch(){
  const searchInputs = $$('.product-search'); // if you place input.product-search in pages
  if(!searchInputs.length) return;

  searchInputs.forEach(input => {
    input.addEventListener('input', e => {
      const q = e.target.value.trim().toLowerCase();
      const gridSel = e.target.dataset.target || '#all-grid';
      const grid = document.querySelector(gridSel);
      if(!grid) return;
      const cards = $$('[data-product]', grid);
      cards.forEach(card => {
        const name = (card.dataset.name || '').toLowerCase();
        const tags = (card.dataset.tag || '').toLowerCase();
        const match = q === '' || name.includes(q) || tags.includes(q);
        card.style.display = match ? '' : 'none';
      });
    });
  });
}

/* ---------- Lightbox gallery ---------- */
function initLightbox(){
  // create modal element
  const existing = $('#odm-lightbox');
  if(existing) return;
  const modal = document.createElement('div');
  modal.id = 'odm-lightbox';
  modal.style.cssText = "position:fixed;top:0;left:0;right:0;bottom:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.85);z-index:2000;padding:1rem;";
  modal.innerHTML = `<div style="max-width:900px;width:100%;"><img id="odm-lightbox-img" style="width:100%;height:auto;border-radius:8px;display:block"/><div style="text-align:right;margin-top:.5rem;"><button id="odm-lightbox-close" class="button alt">Close</button></div></div>`;
  document.body.appendChild(modal);

  // delegate clicks on images that are inside [data-lightbox] or images inside product cards
  document.addEventListener('click', (e) => {
    const img = e.target.closest('[data-lightbox]') || e.target.closest('[data-product] img');
    if(!img) return;
    const src = img.tagName === 'IMG' ? img.src : img.getAttribute('data-src');
    $('#odm-lightbox-img').src = src;
    modal.style.display = 'flex';
  });

  $('#odm-lightbox-close').addEventListener('click', () => modal.style.display = 'none');
  modal.addEventListener('click', (e) => { if(e.target === modal) modal.style.display = 'none'; });
}

/* ---------- Simple animations (on-load) ---------- */
function initAnimations(){
  // fade-in for elements with .fade-in
  window.requestAnimationFrame(()=> {
    $$('.fade-in').forEach(el => el.style.opacity = 1);
  });
}

/* ---------- Form helpers for validation (enquiry/contact) ---------- */
function simpleFormValidation(){
  // This function attaches 'input' validation visuals for inputs with .input
  $$('input.input, textarea.input, select.input').forEach(inp => {
    inp.addEventListener('invalid', () => inp.classList.add('invalid'));
    inp.addEventListener('input', () => inp.classList.toggle('invalid', !inp.checkValidity()));
  });
}

// Contact form module 
(function contactModule(){
  const form = document.getElementById('contact-form');
  if(!form) return;
  const FORMSPREE_ID = 'mwpyvnbg';
  const FORMSPREE_ENDPOINT = `https://formspree.io/f/${FORMSPREE_ID}`;
  const overlay = document.getElementById('contact-overlay');
  const overlayEmail = document.getElementById('overlay-email');
  const overlayClose = document.getElementById('overlay-close');
  const loading = document.getElementById('contact-loading');
  const errorEl = document.getElementById('contact-error');
  const resultEl = document.getElementById('contact-result');

  function showError(msg){ if(errorEl){ errorEl.textContent = msg; errorEl.style.display = 'block'; } }
  function clearError(){ if(errorEl){ errorEl.style.display = 'none'; errorEl.textContent = ''; } }

  function openMailto(payload){
    const to = 'hello@oudemarni.com';
    const subject = encodeURIComponent(payload.subject || `Website message: ${payload.type}`);
    const body = encodeURIComponent(`Name: ${payload.name}\nEmail: ${payload.email}\nType: ${payload.type}\n\nMessage:\n${payload.message}`);
    window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
  }

  if(overlayClose) overlayClose.addEventListener('click', () => { overlay.style.display = 'none'; overlay.setAttribute('aria-hidden','true'); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearError();
    resultEl.innerHTML = '';
    if(!form.checkValidity()){ showError('Please complete the required fields correctly.'); return; }
    const fd = new FormData(form);
    const payload = { name: fd.get('name').trim(), email: fd.get('email').trim(), type: fd.get('type').trim(), subject: fd.get('subject').trim(), message: fd.get('message').trim() };

    loading.style.display = 'inline-block';
    form.querySelector('button[type="submit"]').disabled = true;

    try {
      const res = await fetch(FORMSPREE_ENDPOINT, { method: 'POST', body: fd, headers: { 'Accept': 'application/json' }});
      if(res.ok){
        overlayEmail.textContent = payload.email;
        overlay.style.display = 'flex';
        overlay.setAttribute('aria-hidden','false');
        resultEl.innerHTML = `<div class="card"><div class="card-body"><h3>Thanks ${payload.name} — message sent</h3><p class="small">We will reply to ${payload.email} as soon as possible.</p></div></div>`;
        form.reset();
      } else {
        showError('Server error; opening email client as fallback.');
        openMailto(payload);
      }
    } catch(err){
      showError('Network error; opening email client as fallback.');
      openMailto(payload);
    } finally {
      loading.style.display = 'none';
      form.querySelector('button[type="submit"]').disabled = false;
    }
  });
})();


/* ---------- Boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  updateCartBadge();
  initQuiz();
  initCheckout();
  initSearch();
  initLightbox();
  initAnimations();
  simpleFormValidation();
});
